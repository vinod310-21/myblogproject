from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from .models import Courier
import uuid

# Home page
def home(request):
    return render(request, 'home.html')

# Add courier
def add_courier(request):
    if request.method == "POST":
        tracking_id = str(uuid.uuid4())[:8]

        Courier.objects.create(
            tracking_id=tracking_id,
            sender_name=request.POST['sender'],
            receiver_name=request.POST['receiver'],
            origin=request.POST['origin'],
            destination=request.POST['destination']
        )
        return render(request, 'success.html', {"tracking_id": tracking_id})

    return render(request, 'add.html')

# Track courier
def track_courier(request):
    courier = None
    if request.method == "POST":
        tracking_id = request.POST['tracking_id']
        courier = Courier.objects.filter(tracking_id=tracking_id).first()

    return render(request, 'track.html', {"courier": courier})